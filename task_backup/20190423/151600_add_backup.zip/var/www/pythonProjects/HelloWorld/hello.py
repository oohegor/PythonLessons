#!/usr/bin/env python3

print("Hello World")    # print - это функция

